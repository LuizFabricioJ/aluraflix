import { BrowserRouter, Route, Routes } from "react-router-dom";
import Inicio from "./pages/inicio";
import Player from "./pages/Player";
import NaoEncontrado from "./pages/NaoEncontrado";
import PaginaBase from "./pages/PaginaBase";
import Formulario from "./pages/Formulario";
 

function AppRoutes() {
    return (
        < BrowserRouter>
            <Routes>
                <Route path="/" element={<PaginaBase />}>
                   <Route index element={<Inicio />}></Route>
                   <Route path="formulario" element={<Formulario />}></Route>
                   <Route path=":id" element={<Player />}></Route>
                   <Route path="*" element={<NaoEncontrado />}></Route>
                </Route>
            </Routes>    
        </BrowserRouter>
    )
}
export default AppRoutes;