import style from './Formulario.module.css';
import CampoTexto from '../../components/CampoTexto';

function Formulario() {
    return (
      
        <section className={style.formulario}>
           <form>
              <CampoTexto label="Nome" placeholder="Digite o nome..," />
              <CampoTexto label="Imagem" placeholder="Insira a imagem..," />
              <CampoTexto label="Link" placeholder="Insera o link..," />
           </form>
        </section>
    )
}
export default Formulario;