import { Outlet } from "react-router-dom";
import Container from "../../components/Container";
import Footer from "../../components/Footer";
import Menu from "../../components/Menu";

function PaginaBase() {
    return (
      <main>

        <Menu />
        <Container >
            <Outlet />
        </Container>
        <Footer />
        
      </main>
    )
}
export default PaginaBase;