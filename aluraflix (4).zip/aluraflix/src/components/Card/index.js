import { Link } from 'react-router-dom';
import styles from './Card.module.css';

function Card({id, titulo, capa}) {
    console.log(id, titulo, capa)
    return (
        <div className={styles.container}>
            <Link className={styles.link} to={`/${id}`}>
                <img src={capa} alt={titulo} className={styles.capa} />
                <h2>{titulo}</h2>
            </Link>
        </div>
    )
}
export default Card;