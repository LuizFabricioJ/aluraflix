import styles from './Banner.module.css';

function Banner({ imagem }) {
    return (
        <div className={styles.capa}
            style={{ backgroundImage: `url('/imagens/banner-${imagem}.png')` }}>
                <div className={styles.apresentacao}>
                    <h1 className={styles.titulo}>
                        FRONT-END
                    </h1>
                    <h1 className={styles.titulo1}>
                        SEO com React
                    </h1>
                    <p className={styles.texto}>
                        Esse desafio é uma forma de aprendizado. É um mecanismo onde você pode se
                        engajar na resolução de um problema para pode aplicar todo o conhecimento
                        adquirido na Formação React.
                    </p>

                </div>

        </div>
    )
}

export default Banner;