import styles from './Footer.module.css';

function Footer(){
    return (
        < footer className={styles.Footer}>
            <h2>Desenvolvido por Luiz Fabricio de Souza Junior.</h2>
        </footer>
    )
}
export default Footer;