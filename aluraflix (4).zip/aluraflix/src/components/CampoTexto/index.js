import style from './CampoTexto.module.css';

function CampoTexto(props) {
    return (
      <div className={style.caixa}>
        <label>{props.label}</label>
        <input placeholder={props.placeholder} />
      </div>
    )
}
export default CampoTexto;