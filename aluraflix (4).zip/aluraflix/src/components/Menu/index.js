import { Link } from "react-router-dom";
import Logo from './Logo.png';
import styles from './Menu.module.css';
import ButtonLink from "../ButtonLink";
import Formulario from "../../pages/Formulario";

function Menu() {
    return (
        <header className={styles.Menu}>
            <Link to="./">
                <img src={Logo} alt="Logo do Aluraflix"></img>
            </Link>
            <nav>
                <ButtonLink url="./novosvideos">
                    Novos videos
                </ButtonLink>
            </nav>
        </header> 
    )
}
export default Menu;